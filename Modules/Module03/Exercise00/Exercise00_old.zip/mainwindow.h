#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QDebug>
#include <QMainWindow>
#include <QPushButton>
#include <QLineEdit>
#include <QListWidget>
#include "ContactList.h"

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();



signals:
    void contactAdded(const Contact &contact); // Signal for adding a contact

private slots:
    void addContact(); // Slot for adding contact
    void editContact(); // Slot for editing contact
    void deleteContact(); // Slot for deleting contact
    void searchContact();

private:
    // Declare the widgets as member variables
    QPushButton *m_addButton;
    QPushButton *m_editButton;
    QPushButton *m_deleteButton;
    QLineEdit *m_searchLineEdit;
    QListWidget *m_contactListWidget;

    ContactList contactList; // Contact list to store contacts

private:
    Ui::MainWindow *ui;


};
#endif // MAINWINDOW_H
