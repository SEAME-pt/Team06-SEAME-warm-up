#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    connect(ui->searchButton, &QPushButton::clicked, this, &MainWindow::searchContact);
    connect(ui->addButton, &QPushButton::clicked, this, &MainWindow::addContact);
    connect(ui->deleteButton, &QPushButton::clicked, this, &MainWindow::deleteContact);
    connect(ui->editButton, &QPushButton::clicked, this, &MainWindow::editContact);






}

MainWindow::~MainWindow()
{
    delete ui;
}



void MainWindow::addContact()
{


   qDebug() << "add";

    /*
    contactList.addContact(newContact);

    // Emitir sinal de contato adicionado
    emit contactAdded(newContact);

    // Adicionar o contato à lista de exibição
    m_contactListWidget->addItem(newContact.name() + " - " + newContact.phone());

*/
}

void MainWindow::editContact()
{
    qDebug() << "edit";

}

void MainWindow::deleteContact()
{
    qDebug() << "delete";

}

void MainWindow::searchContact()
{
    qDebug() << "search";

}
